-- phpMiniAdmin dump 1.9.160630
-- Datetime: 2016-07-12 17:21:27
-- Host: 
-- Database: csc_it_wms

/*!40030 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;

DROP TABLE IF EXISTS `warranties`;
CREATE TABLE `warranties` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `status` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'active',
  `product_name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `company_name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `price` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `notes` varchar(3000) COLLATE utf8_unicode_ci NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `created_by` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Unspecified',
  `creation_date` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*!40000 ALTER TABLE `warranties` DISABLE KEYS */;
INSERT INTO `warranties` VALUES ('0','active','Test Product 1 Warranty','Test Company','$200','This is an active test warranty.','2016-07-12','2016-07-30','Yoseph S. Alabdulwahab','2016-07-12'),('1','expired','Test Product 2 Warranty','Test Company','$150','This is an expired test warranty.','2016-05-12','2016-06-30','Yoseph S. Alabdulwahab','2016-05-12'),('2','canceled','Test Product 3 Warranty','Test Company','$389','This is an canceled test warranty.','2016-07-12','2016-07-30','Yoseph S. Alabdulwahab','2016-07-12');
/*!40000 ALTER TABLE `warranties` ENABLE KEYS */;

/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;


-- phpMiniAdmin dump end
