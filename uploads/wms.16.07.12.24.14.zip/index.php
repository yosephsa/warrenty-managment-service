<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>Warranty Managment System</title>
		<link rel="stylesheet" type="text/css" href="/style.css">
	</head>

	<body>
		<div class="wrapper">
			<?php
				include 'header.php';
			?>
			<form class="search" method="POST">
				<div class="content">
					<text>Product Name: </text>
					<input type="text" name="product_name"/><br/>
					<text>Company Name: </text>
					<input type="text" name="company_name"/><br/>
					<text>Within ( Days ): </text>
					<input type="text" name="date_range"/>
				</div>
				<div class="content">
					<text>Created By: </text>
					<input type="text" name="created_by"/><br/>
					<text>Notes (Contain): </text>
					<input type="text" name="notes"/>
				</div>
				<div class="submission">
					<text>Show</text>
					<input type="text" name="result_amount" id="result_amount" value="20"/> 
					<input type="submit" name="submit" value="submit" onClick="location.reload(false);" id="submit" />
				</div>
			</form>
			<div class="body_content">
				<?php
					//For some reason I still can't find submit from post for some reason.
					if(isset($_POST['submit']))
					{
						include "search_functions.php";
						
						$result_amount = $_POST['result_amount'];
						
						$status = "";
						if(isset($_GET['status'])) {
							$status = $_GET['status'];
						}
						
						$id = "";
						$product_name = $_POST['product_name'];
						$company_name = $_POST['company_name'];
						$notes = $_POST['notes'];
						$date_range = $_POST['date_range'];
						if(isset($_GET['date_range'])) {
							$date_range = $_GET['date_range'];
						}
						$created_by = $_POST['created_by'];
						
						$result_set = search_warranties($id, $status, $product_name, $company_name, $notes, $date_range, $created_by);
						
						$result_set_array = array();
						while($row = mysqli_fetch_array($result_set)) {
							$result_set_array[] = $row;
						}
						
						$i = 0;
						while($i < sizeof($result_set_array) && $i < $result_amount) {
							$id = $result_set_array[$i]['id'];
							$product_name = $result_set_array[$i]['product_name'];
							$company_name = $result_set_array[$i]['company_name'];
							$price = $result_set_array[$i]['price'];
							$notes = $result_set_array[$i]['notes'];
							$start_date = $result_set_array[$i]['start_date'];
							$end_date = $result_set_array[$i]['end_date'];
							$created_by = $result_set_array[$i]['created_by'];
							$creation_date = $result_set_array[$i]['creation_date'];
							echo '<br/>id: ' . $id . ' product name: ' . $product_name . ' company_name: ' . $company_name . ' price: ' . $price . ' notes: ' . $notes . ' ';
							$i = $i + 1;
						}
					} else {
						include "search_functions.php";
						
						$result_amount = 10;
						
						$status = "";
						if(isset($_GET['status'])) {
							$status = $_GET['status'];
						}
						
						$id = "";
						$product_name = "";
						$company_name = "";
						$notes = "";
						$date_range = "";
						if(isset($_GET['date_range'])) {
							$date_range = $_GET['date_range'];
						}
						$created_by = "";
						
						$result_set = search_warranties($id, $status, $product_name, $company_name, $notes, $date_range, $created_by);
						
						$result_set_array = array();
						while($row = mysqli_fetch_array($result_set)) {
							$result_set_array[] = $row;
						}
						
						$i = 0;
						while($i < sizeof($result_set_array) && $i < $result_amount) {
							$id = $result_set_array[$i]['id'];
							$product_name = $result_set_array[$i]['product_name'];
							$company_name = $result_set_array[$i]['company_name'];
							$price = $result_set_array[$i]['price'];
							$notes = $result_set_array[$i]['notes'];
							$start_date = $result_set_array[$i]['start_date'];
							$end_date = $result_set_array[$i]['end_date'];
							$created_by = $result_set_array[$i]['created_by'];
							$creation_date = $result_set_array[$i]['creation_date'];
							echo '<br/>id: ' . $id . ' product name: ' . $product_name . ' company_name: ' . $company_name . ' price: ' . $price . ' notes: ' . $notes . ' ';
							$i = $i + 1;
						}
					} 
				?>
			</div>
		</div>
	</body>

</html>