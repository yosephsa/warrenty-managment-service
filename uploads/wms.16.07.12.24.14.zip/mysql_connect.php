<?php
	function connectDatabase($usr, $pss) {
		include "constants.php";
		if($usr == null || $pss == null)
			return mysqli_connect($dbinfo['HOST_NAME'], $dbinfo['READ_USER'], $dbinfo['READ_PASS'], $dbinfo['DB_NAME']);
		return mysqli_connect($dbinfo['HOST_NAME'], $usr, $pss, $dbinfo['TABLE_NAME']);
	}
	
	function sendPost($usr, $pss, $query) {
		//connection to the database
		$link = connectDatabase($usr, $pss);
		//execute the SQL query
		$result = mysqli_query($link, $query)
			or die("could not send query");
		mysqli_close($link);
	}
?>