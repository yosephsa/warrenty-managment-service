<?php
function search_warranties($id, $status, $product_name, $company_name, $notes, $date_range, $created_by) {
	include 'mysql_connect.php';
	include 'constants.php';
	$dbhandle = connectDatabase("", "");
	$search_fields = " WHERE ";
	if($id != "") {
		$search_fields .= "id = '".mysqli_real_escape_string($dbhandle, $id)."'";
	} else {
		if($status != "") {
			$search_fields .= " status = '".mysqli_real_escape_string($dbhandle, $status)."' ";
		}
		if($product_name != "") {
			if($search_fields != " WHERE ")
				$search_fields .= "AND";
			$search_fields .= " product_name LIKE '%".mysqli_real_escape_string($dbhandle, $product_name)."%' ";
		}
		if($company_name != "") {
			if($search_fields != " WHERE ")
				$search_fields .= "AND";
			$search_fields .= " company_name LIKE '%".mysqli_real_escape_string($dbhandle, $company_name)."%' ";
		}
		if($notes != ""){
			if($search_fields != " WHERE ")
				$search_fields .= "AND";
			$search_fields .= " notes LIKE '%".mysqli_real_escape_string($dbhandle, $notes)."%' ";
		}
		if($created_by != "") {
			if($search_fields != " WHERE ")
				$search_fields .= "AND";
			$search_fields .= " created_by LIKE '%".mysqli_real_escape_string($dbhandle, $created_by)."%' ";
		}
		if($date_range != "") {
			if($search_fields != " WHERE ")
				$search_fields .= "AND";
			$dr = "+0";
			if(substr($date_range, 0, 1) != '-' || substr($date_range, 0, 1) != '+')
				$dr = '+'.$date_range;
			else
				$dr = mysqli_real_escape_string($dbhandle, $date_range);
			$dr .= " day";
			$dr_start_time = strtotime("today");
			$dr_end_time = strtotime($dr, $dr_start_time);
			$dr_start_date = date("Y-m-d", $dr_start_time);
			$dr_end_date = date("Y-m-d", $dr_end_time);
			$search_fields .= " end_date between '".$dr_start_date."' AND '".$dr_end_date."' ";
		}
		if($search_fields == " WHERE ")
			$search_fields = "";
	}
	
	$query = "SELECT * FROM " . mysqli_real_escape_string($dbhandle, $dbinfo['TABLE_NAME']) . $search_fields . " ORDER BY end_date DESC";
	echo $query;
	$result_set = mysqli_query($dbhandle, $query);
	return $result_set;
}

?>