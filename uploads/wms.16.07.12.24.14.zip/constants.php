<?php

$dbinfo = array("HOST_NAME"=>"localhost",
					"DB_NAME"=>"csc_it_wms",
					"TABLE_NAME"=>"warranties",
					"READ_USER"=>"csc_it_wms_read",
					"READ_PASS"=>"Read@123");
					
?>