<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>Warranty Managment System</title>
		<link rel="stylesheet" type="text/css" href="/style.css">
	</head>

	<body>
		<div class="wrapper">
			<?php
				include 'header.php';
			?>
			<div class="control_menu">
				<form class="access_info">
						<text> Username: </text>
						<textarea name="username"></textarea>
						<br/>
						<text> Password: </text>
						<textarea name="password"></textarea>
				</form>
				<div class="actions">
					<input type="submit" value="Edit" name="edit"/>
					<input type="submit" value="Delete" name="delete"/>
				</div>
			</div>
			<div class="body_content">
				<?php
					if(isset($_GET['id']))
					{
					   search_by_id($_GET['id']);
					}
					function search()
					{
					}
					function search_by_id($id)
					{
						if($id == 1) {
							$title = "Kasper Sky Anti Virus Warranty";
							$author = "Yoseph S. Alabdulwahab";
							$date = "9 December 2016";
							$company = "Kasper Sky";
							$price = "$300";
							$priority = "Low";
							$description = "Security is important, I guess...";
						} else if($id == 2) {
							$title = "Refridgurator Hight Quality Warranty";
							$author = "Fahad A. Alsuraibi";
							$date = "28 February 2030";
							$company = "Yoseph's Super White Refridguration";
							$price = "$14,000";
							$priority = "High";
							$description = "We mustb be able to drink cold water from nice fridges.";
						} else {
							return false;
						}
						echo "<div class=\"entry\">
								<div class=\"content\">
									<div class=\"header\">
										<textarea class=\"title\"> <a href=\"/search.php?id=".$id."\">".$title."</a></textarea>
										<textarea class=\"date\">".$date."</textarea>
									</div>
									<hr/>
									<div class=\"details\"><br/>
										<p> Owner: <textarea>".$author."</textarea> </p><br/>
										<p> Company Name: <textarea>".$company."</textarea> </p><br/>
										<p> Price: <textarea>".$price."</textarea> </p><br/>
										<p> Priority: <textarea>".$priority."</textarea> </p><br/>
										<p> Description: <textarea>".$description."</textarea> </p>
									</div>
								</div>
								
								
							</div>
							";
					}
				?>
			</div>
		</div>
	</body>

</html>