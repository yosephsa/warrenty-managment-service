<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>Warranty Managment System</title>
		<link rel="stylesheet" type="text/css" href="/style.css">
	</head>

	<body>
		<div class="wrapper">
			<?php
				include 'header.php';
			?>
			<div class="control_menu">
				<form class="access_info">
						<text> Username: </text>
						<textarea name="username"></textarea>
						<br/>
						<text> Password: </text>
						<textarea name="password"></textarea>
				</form>
				<div class="actions">
					<input type="submit" value="Edit" name="edit"/>
					<input type="submit" value="Delete" name="delete"/>
				</div>
			</div>
			<div class="body_content">
				<?php
					if(isset($_GET['id']))
					{
						include "search_functions.php";
						
						$status = "";
						
						$id = $_GET['id'];
						$product_name = "";
						$company_name = "";
						$notes = "";
						$date_range = "";
						$created_by = "";
						
						$result_set = search_warranties($id, $status, $product_name, $company_name, $notes, $date_range, $created_by);
						
						$result_set_array = array();
						while($row = mysqli_fetch_array($result_set)) {
							$result_set_array[] = $row;
						}
						
						$i = 0;
						while($i < sizeof($result_set_array)) {
							$id = $result_set_array[$i]['id'];
							$product_name = $result_set_array[$i]['product_name'];
							$company_name = $result_set_array[$i]['company_name'];
							$price = $result_set_array[$i]['price'];
							$notes = $result_set_array[$i]['notes'];
							$start_date = $result_set_array[$i]['start_date'];
							$end_date = $result_set_array[$i]['end_date'];
							$created_by = $result_set_array[$i]['created_by'];
							$creation_date = $result_set_array[$i]['creation_date'];
							echo '<br/>id: ' . $id . ' product name: ' . $product_name . ' company_name: ' . $company_name . ' price: ' . $price . ' notes: ' . $notes . ' ';
							$i = $i + 1;
						}
					}
					
				?>
			</div>
		</div>
	</body>

</html>