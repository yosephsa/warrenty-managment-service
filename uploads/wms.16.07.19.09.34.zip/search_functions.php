<?php
function search_warranties($id, $status, $product_name, $company_name, $contact_info, $notes, $date_range, $created_by) {
	include_once 'mysql_connect.php';
	include_once 'constants.php';
	$prefs = get_preferences();
	$search_fields = " WHERE ";
	if($id != "") {
		$search_fields .= "id = '".$id."'";
	} else {
		if($status != "") {
			$search_fields .= " status = '".$status."' ";
		}
		if($product_name != "") {
			if($search_fields != " WHERE ")
				$search_fields .= "AND";
			$search_fields .= " product_name LIKE '%".$product_name."%' ";
		}
		if($company_name != "") {
			if($search_fields != " WHERE ")
				$search_fields .= "AND";
			$search_fields .= " company_name LIKE '%". $company_name."%' ";
		}
		if($contact_info != ""){
			if($search_fields != " WHERE ")
				$search_fields .= "AND";
			$search_fields .= " contact_info LIKE '%".$contact_info."%' ";
		}
		if($notes != ""){
			if($search_fields != " WHERE ")
				$search_fields .= "AND";
			$search_fields .= " notes LIKE '%". $notes."%' ";
		}
		if($created_by != "") {
			if($search_fields != " WHERE ")
				$search_fields .= "AND";
			$search_fields .= " created_by LIKE '%".$created_by."%' ";
		}
		if($date_range != "") {
			if($search_fields != " WHERE ")
				$search_fields .= "AND";
			$dr = "+0";
			if(substr($date_range, 0, 1) != '-' || substr($date_range, 0, 1) != '+')
				$dr = '+'.$date_range;
			else
				$dr =  $date_range;
			$dr .= " day";
			$dr_start_time = strtotime("today");
			$dr_end_time = strtotime($dr, $dr_start_time);
			$dr_start_date = date("Y-m-d", $dr_start_time);
			$dr_end_date = date("Y-m-d", $dr_end_time);
			$search_fields .= " end_date between '".$dr_start_date."' AND '".$dr_end_date."' ";
		}
		if($search_fields == " WHERE ")
			$search_fields = "";
	}
	
	$query = "SELECT * FROM " . $prefs['mysql_table_warranties'] . $search_fields . " ORDER BY end_date ASC ";
	$result_set = db_query($query);
	return $result_set;
}

function date_in_range($start_date, $end_date, $date_input)
{
  // Convert to timestamp
  $start_ts = strtotime($start_date);
  $end_ts = strtotime($end_date);
  $user_ts = strtotime($date_input);

  // Check that user date is between start & end
  return (($user_ts >= $start_ts) && ($user_ts <= $end_ts));
}

?>