<!DOCTYPE html>
<html>
	<head>
		<?php
			include_once 'required_imports.php';
		?>
		<title>Warranty Managment System</title>
	</head>

	<body>
		<div class="wrapper">
			<?php
				include_once 'header.php';
			?>
			<form method="POST">
				<div class="control_menu">
					<?php
					include_once 'login.php';
					?>
					<div class="actions">
						<input type="submit" value="Create" name="create"/>
						<input type="submit" value="Back" name="back"/>
					</div>
				</div>
				<div class="body_content">
					<div class="entry">
						<div class="content">
							<div class="header">
								<div class="title"><p>Product Name: </p><input type="text" name="product_name" value=""></input></div>
								
								<div class="date"><p>Company Name: </p><input type="text" name="company_name" value=""></input></div>
								
							</div>
							<hr/>
							<div class="details"><br/>
								<?php echo '<p>Warranty Period: <input type="text" name="start_date" value="'.date('j F Y', strtotime("today")).'"></input> to <input type="text" name="end_date" value="' .date('j F Y', strtotime("today")).'"></input></p><br/>';?>
								<p>Price: </p><input type="text" name="price" value=""></input><br/>
								<p>Contact Info: </p><div class="contact_info"><textarea name="contact_info" id="contact_info" class="contact_info"></textarea></div>
								<p>Notes: </p><div class="notes"><textarea name="notes" id="notes" class="notes"></textarea></div>
							</div>
						</div>
						<div class="actions" style="padding-top: 4em;">
							<br/><hr/><br/>
							<input type="submit" value="Create" name="create"/>
							<input type="submit" value="Cancel" name="back"/>
						</div>
					</div>
					<script>tinymce.init({ selector:'textarea'});</script>
					<?php
						if(isset($_POST['back'])) {
							echo '<script type="text/javascript">window.history.go(-2);</script>';
						}
						if(isset($_POST['create']) && isset($_POST['username'] ) && isset($_POST['password'])) {
							//Include necessaru files.
							include_once 'mysql_connect.php';
							include_once 'search_functions.php';
							include_once "user_auth.php";
							include_once 'constants.php';
							$prefs = get_preferences();
							
							//Check if required fields are blank.
							if($_POST['username'] == "" || $_POST['password'] == "") {
								echo "<script type='text/javascript'>alert('Please don\'t leave required fields black.')</script>";
								echo "<script type='text/javascript'>window.history.back()</script>";
								goto end_if_007;
							}
							
							//authenticate username and password.
							$auth_status = authenticate($_POST['username'], $_POST['password']);
							if($auth_status == 0) {
								if(isset($_POST['create'])) {
									//Get name of user.
									$user_result = db_query("SELECT * FROM ".$prefs['mysql_table_users']." WHERE username='".$_POST['username']."'");
									$user_result_arr = mysqli_fetch_array($user_result);
									$first_name = $user_result_arr['first_name'];
									$middle_name = $user_result_arr['middle_name'];
									$last_name = $user_result_arr['last_name'];
									//Creating query string
									$query = 'INSERT INTO '. $prefs["mysql_table_warranties"] .'
										(status, product_name, company_name, price, contact_info, notes, start_date, end_date, created_by, creation_date)
										VALUES 
										  ( 
										    "active",
											"'.addslashes($_POST['product_name']).'", 
											"'.addslashes($_POST['company_name']).'",
											"'.addslashes($_POST['price']).'",
											"'.addslashes($_POST['contact_info']).'",
											"'.addslashes($_POST['notes']).'",
											"'.date("Y-m-d", strtotime($_POST['start_date'])).'",
											"'.date("Y-m-d", strtotime($_POST['end_date'])).'",
											"' . $first_name . " " . $middle_name . " " . $last_name . '",
											"'.date("y-m-d", strtotime("today")).'" )
										';
									echo htmlentities($query);
									//Sending query.
									$update_result = db_query($query);
									if(!$update_result){
										echo "<script type='text/javascript'>alert('Could not create warranty.')</script>";
										//echo "<script type='text/javascript'>window.history.back()</script>";
										goto end_if_007;
									}
									$result = db_query('SELECT * FROM '.$prefs['mysql_table_warranties'].' WHERE creation_date="'.date("y-m-d", strtotime("today")).'" AND product_name="'.$_POST['product_name'].'"');
									$id = mysqli_fetch_array($result)['id'];
									echo $id;
									echo "<script type='text/javascript'>window.location.assign('../search.php/?id=".$id."')</script>";
								}
							} else if($auth_status == 1) {
								echo "<script type='text/javascript'>alert('The username or password you entered is incorrect.')</script>";
							
							} else if($auth_status == 2) {
								echo "<script type='text/javascript'>alert('Could not connect to database.')</script>";
							} else{
								echo "<script type='text/javascript'>alert('Could not authenticate for an unknown reason.')</script>";
							}
							end_if_007:
						}
						
					?>
				
				</div>
			</form>
		</div>
	</body>

</html>