<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>Warranty Managment System</title>
		<link rel="stylesheet" type="text/css" href="/style.css">
	</head>

	<body>
		<div class="wrapper">
			<?php
				include_once 'header.php';
			?>
			
			<form method="POST">
				<div class="control_menu">
					<?php
					include_once 'login.php';
					?>
				</div>
				
				<div class="body_content">
					<div class="entry">
						<div class="content">
							<div class="header">
								<div class="title"><p>User Control Settings: </p></div>
							</div>
							<hr/>
							<div class="details"><br/>
							<?php
								include_once 'mysql_connect.php';
								include_once 'user_auth.php';
								include_once 'constants.php';
								$prefs = get_preferences();
								if(isset($_POST['list_all_accounts'])) {
									//Authenticate user
									if(addslashes($_POST['username']) == "" || addslashes($_POST['password']) == "") {
										echo "<script type='text/javascript'>alert('Please don\'t leave required fields black.')</script>";
										echo '<script type="text/javascript">window.history.back();</script>';
										goto end_if_101;
									}
									$auth_status = authenticateAdmin(addslashes($_POST['username']), addslashes($_POST['password']));
									if($auth_status != 0) {
										echo "<script type='text/javascript'>alert('The username and password combination is wrong or you don\'t have permission to do this')</script>";
										echo '<script type="text/javascript">window.history.back();</script>';
										goto end_if_101;
									}
									
									//Retrieving user base.
									$query = 'SELECT * FROM '.$prefs['mysql_table_users'].'';
									$result = db_query($query);
									if(!$result || mysqli_num_rows($result) == 0) {
										echo "<script type='text/javascript'>alert('There are no registered users.')</script>";
										echo '<script type="text/javascript">window.history.back();</script>';
										goto end_if_101;
									}
									//$result_arr = mysqli_fetch_array($result);
									
									//Printing user base.
									echo '
										<table style="width:100%">
											<tr>
												<th style="font-weight: bold;">Name</th>
												<th style="font-weight: bold;">Username</th>
												<th style="font-weight: bold;">Permission</th>
												<th style="font-weight: bold;">Email</th>
												<th style="font-weight: bold;">Creation Date</th>
											</tr>
									';
									while($row = mysqli_fetch_array($result)) {
										echo '
											<tr>
												<th style="font-weight: normal;">'.$row['first_name'] .' '.$row['middle_name'].' '.$row['last_name'].'</th>
												<th style="font-weight: normal;">'.$row['username'].'</th>
												<th style="font-weight: normal;">'.$row['permission'].'</th>
												<th style="font-weight: normal;">'.$row['email'].'</th>
												<th style="font-weight: normal;">'.$row['creation_date'].'</th>
											</tr>
										';
									}
									echo '</table>';
									
									echo '<br/><hr/><br/><input type="submit" value="Back" name="back"/>';
									end_if_101:
									
								} else if(isset($_POST['edit_account'])) {
									//Authenticate user
									if(addslashes($_POST['username']) == "" || addslashes($_POST['password']) == "") {
										echo "<script type='text/javascript'>alert('Please don\'t leave required fields black.')</script>";
										echo '<script type="text/javascript">window.history.back();</script>';
										goto end_if_102;
									}
									$auth_status = authenticateAdmin(addslashes($_POST['username']), addslashes($_POST['password']));
									if($_POST['username'] == addslashes($_POST['edit_account_username']))
										$auth_status = authenticate(addslashes($_POST['username']), addslashes($_POST['password']));
									if($auth_status != 0) {
										echo "<script type='text/javascript'>alert('The username and password combination is wrong or you don\'t have permission to do this')</script>";
										echo '<script type="text/javascript">window.history.back();</script>';
										goto end_if_102;
									}
									$query = 'SELECT * FROM '.$prefs['mysql_table_users'].' WHERE username="'.addslashes($_POST['edit_account_username']).'"';
									$result = db_query($query);
									if(!$result || mysqli_num_rows($result) == 0) {
										echo '<script type="text/javascript">alert("Request user to delete does not exist.")</script>';
										echo '<script type="text/javascript">window.history.back();</script>';
										goto end_if_102;
									}
									//Fetch account information.
									$result_arr = mysqli_fetch_array($result);
									//Print info to page
									$editibility = "readonly";
									$password_fields = "";
									if(addslashes($_POST['edit_account_username']) == addslashes($_POST['username'])) {
										$editibility = "";
										$password_fields = '
											<p>New password: <input type="password" name="edit_account_password" value=""/></p>
											<p>Retype new password: <input type="password" name="edit_account_password_retype" value=""/></p>
										';
									}
									$admin_selected = "";
									if($result_arr['permission'] == 'admin')
										$admin_selected = 'selected';
									$notify_checked = '';
									if($result_arr['notify'] == 1) {
										$notify_checked = 'checked';
									}
									echo '
											<table style="width:100%;" class="user_name">
												<tr>
													<th>First</th>
													<th>M.I.</th>
													<th>Last</th>
												</tr>
												<tr>
													<th><input type="text" name="edit_account_first_name" value="'.$result_arr['first_name'].'" '.$editibility.'/></th>
													<th><input type="text" name="edit_account_middle_name" value="'.$result_arr['middle_name'].'" '.$editibility.'/></th>
													<th><input type="text" name="edit_account_last_name" value="'.$result_arr['last_name'].'" '.$editibility.'/></th>
												</tr>
											</table>
										<p>Username: <input type="text" name="edit_account_username" value="'.$result_arr['username'].'" readonly/></p>
										<p>Email: <input type="text" name="edit_account_email" value="'.$result_arr['email'].'" '.$editibility.'/></p>
										<p>Birth date: <input type="text" name="edit_account_birth_date" value="'.date("j F Y", strtotime($result_arr['birth_date'])).'" '.$editibility.'/></p>
										<p>
											Permission: 
											<select name="edit_account_permission">
												<option value="user">Default User</option>
												<option value="admin" '.$admin_selected.'>Admin</option>
											</select>
										</p>
										<p>Email Notification: <input type="checkbox" name="edit_account_notify" '.$notify_checked.'/></p>
										'.$password_fields.'
										
									';
									
									echo '<br/><hr/><br/>
									<input type="submit" value="Edit" name="edit_account_submit"/>
									<input type="submit" value="Back" name="back"/>';
									end_if_102:
								} else if(isset($_POST['create_account'])) {
									//Authenticate user
									if(addslashes($_POST['username']) == "" || addslashes($_POST['password']) == "") {
										echo "<script type='text/javascript'>alert('Please don\'t leave required fields black.')</script>";
										echo '<script type="text/javascript">window.history.back();</script>';
										goto end_if_103;
									}
									$auth_status = authenticateAdmin(addslashes($_POST['username']), addslashes($_POST['password']));
									if($auth_status != 0) {
										echo "<script type='text/javascript'>alert('The username and password combination is wrong or you don\'t have permission to do this')</script>";
										echo '<script type="text/javascript">window.history.back();</script>';
										goto end_if_103;
									}
									echo '
											<table style="width:100%;" class="user_name">
												<tr>
													<th>First</th>
													<th>M.I.</th>
													<th>Last</th>
												</tr>
												<tr>
													<th><input type="text" name="create_account_first_name" value="" /></th>
													<th><input type="text" name="create_account_middle_name" value="" /></th>
													<th><input type="text" name="create_account_last_name" value="" /></th>
												</tr>
											</table>
										<p>Username: <input type="text" name="create_account_username" value="" /></p>
										<p>Email: <input type="text" name="create_account_email" value="" /></p>
										<p>Birth date: <input type="text" name="create_account_birth_date" value="'.date("j F Y", strtotime("today")).'" /></p>
										<p>
											Permission: 
											<select name="create_account_permission">
												<option value="user">Default User</option>
												<option value="admin">Admin</option>
											</select>
										</p>
										<p>Email Notification: <input type="checkbox" name="create_account_notify"/></p>
										<p>Password: <input type="password" name="create_account_password" value=""/></p>
										<p>Retype password: <input type="password" name="create_account_password_retype" value=""/></p>
										
									';
									
									echo '<br/><hr/><br/>
											<input type="submit" value="Create" name="create_account_submit"/>
											<input type="submit" value="Back" name="back"/>';
									end_if_103:
								} else if(isset($_POST['remove_account'])) {
									//Authenticate user
									if(addslashes($_POST['username']) == "" || addslashes($_POST['password']) == "") {
										echo "<script type='text/javascript'>alert('Please don\'t leave required fields black.')</script>";
										echo '<script type="text/javascript">window.history.back();</script>';
										goto end_if_104;
									}
									$auth_status = authenticateAdmin(addslashes($_POST['username']), addslashes($_POST['password']));
									if($auth_status != 0) {
										echo "<script type='text/javascript'>alert('The username and password combination is wrong or you don\'t have permission to do this')</script>";
										echo '<script type="text/javascript">window.history.back();</script>';
										goto end_if_104;
									}
									$query = 'SELECT * FROM '.$prefs['mysql_table_users'].' WHERE username="'.addslashes($_POST['remove_account_username']).'"';
									$result = db_query($query);
									if(!$result || mysqli_num_rows($result) == 0) {
										echo '<script type="text/javascript">alert("Request user to delete does not exist.")</script>';
										echo '<script type="text/javascript">window.history.back();</script>';
										goto end_if_104;
									}
									//Fetch account information.
									$result_arr = mysqli_fetch_array($result);
									
									//Print info to page
									echo '
										<p>
										<text style="font-size: 1.2em;">Are you sure you would like to remove this account? </text><br/>
										This is not undoable.
										</p>
										<p>Please type the username <input type="text" name="remove_account_username" value="'.addslashes($_POST['remove_account_username']).'" readonly/> again: <input type="text" name="remove_account_verify_username"/></p>
										';
									
									echo '	<br/><hr/><br/>
											<input type="submit" value="Remove" name="remove_account_submit" style="margin:0.6";/>
											<input type="submit" value="Cancel" name="remove_account_cancel"/>';
									end_if_104:
								} else if(isset($_POST['remove_account_submit'])) {
									//Authenticate user
									if(addslashes($_POST['username']) == "" || addslashes($_POST['password']) == "") {
										echo "<script type='text/javascript'>alert('Please don\'t leave required fields black.')</script>";
										echo '<script type="text/javascript">window.history.back();</script>';
										goto end_if_105;
									}
									$auth_status = authenticateAdmin(addslashes($_POST['username']), addslashes($_POST['password']));
									if($auth_status != 0) {
										echo "<script type='text/javascript'>alert('The username and password combination is wrong or you don\'t have permission to do this')</script>";
										echo "<script type='text/javascript'>window.history.back()</script>";
										goto end_if_105;
									}
									//Check verification
									if(addslashes($_POST['remove_account_username']) != addslashes($_POST['remove_account_verify_username'])) {
										echo "<script type='text/javascript'>alert('Please retype the username correctly.')</script>";
										echo '<script type="text/javascript">window.history.back();</script>';
										goto end_if_105;
									}
									
									$query = 'DELETE FROM '.$prefs['mysql_table_users'].' WHERE username="'.addslashes($_POST['remove_account_username']).'"';
									$query_result = db_query($query);
									if(!$query_result) {
										echo "<script type='text/javascript'>alert('Could not delete account.')</script>";
										echo '<script type="text/javascript">window.history.back();</script>';
										goto end_if_105;
									}
									echo "<script type='text/javascript'>window.location.assign('../settings.php/')</script>";
									end_if_105:
								} else if(isset($_POST['edit_account_submit'])) {
									//Authenticate user
									if(addslashes($_POST['username']) == "" || addslashes($_POST['password']) == "") {
										echo "<script type='text/javascript'>alert('Please don\'t leave required fields black.')</script>";
										echo '<script type="text/javascript">window.history.back();</script>';
										goto end_if_106;
									}
									$auth_status = authenticateAdmin(addslashes($_POST['username']), addslashes($_POST['password']));
									$edit_as_admin = true;
									if(addslashes($_POST['username']) == addslashes($_POST['edit_account_username'])) {
										$auth_status = authenticate(addslashes($_POST['username']), addslashes($_POST['password']));
										$edit_as_admin = false;
									}
									if($auth_status != 0) {
										echo "<script type='text/javascript'>alert('The username and password combination is wrong')</script>";
										echo '<script type="text/javascript">window.history.back();</script>';
										goto end_if_106;
									}
									//check if new password requested match
									if(!$edit_as_admin && addslashes($_POST['edit_account_password']) != "" && addslashes($_POST['edit_account_password']) != addslashes($_POST['edit_account_password_retype'])) {
										echo "<script type='text/javascript'>alert('New password donsen\'t match the retype field.')</script>";
										echo '<script type="text/javascript">window.history.back();</script>';
										goto end_if_106;
									}
									//Check if requested account exists.
									$query = 'SELECT * FROM '.$prefs['mysql_table_users'].' WHERE username="'.addslashes($_POST['edit_account_username']).'"';
									$result = db_query($query);
									if(!$result || mysqli_num_rows($result) == 0) {
										echo '<script type="text/javascript">alert("Request user to delete does not exist.")</script>';
										echo '<script type="text/javascript">window.history.back();</script>';
										goto end_if_106;
									}
									//Fetch account information.
									$result_arr = mysqli_fetch_array($result);
									$new_account = array('email'=>addslashes($_POST['edit_account_email']), 'username'=>addslashes($_POST['edit_account_username']), 'first_name'=>addslashes($_POST['edit_account_first_name']), 'middle_name'=>addslashes($_POST['edit_account_middle_name']), 'last_name'=>addslashes($_POST['edit_account_last_name']), 'birth_date'=>addslashes($_POST['edit_account_birth_date']), 'permission'=>addslashes($_POST['edit_account_permission']));
									if(!$edit_as_admin)
										$new_account = array('email'=>addslashes($_POST['edit_account_email']), 'username'=>addslashes($_POST['edit_account_username']), 'first_name'=>addslashes($_POST['edit_account_first_name']), 'middle_name'=>addslashes($_POST['edit_account_middle_name']), 'last_name'=>addslashes($_POST['edit_account_last_name']), 'birth_date'=>addslashes($_POST['edit_account_birth_date']), 'permission'=>addslashes($_POST['edit_account_permission']), 'password'=>addslashes($_POST['edit_account_password']));
									
									//Update account data
									if($edit_as_admin) {
										$query = 'UPDATE '.$prefs['mysql_table_users'].'
										SET
											permission="'.$new_account['permission'].'"
										WHERE
											username="'.$new_account['username'].'"
									';
									} else {
										$notify_value = 1;
										if (!isset($_POST['edit_account_notify']))
											$notify_value = 0;
										$query = 'UPDATE '.$prefs['mysql_table_users'].'
											SET
												email="'.$new_account['email'].'",
												first_name="'.$new_account['first_name'].'",
												middle_name="'.$new_account['middle_name'].'",
												last_name="'.$new_account['last_name'].'",
												permission="'.$new_account['permission'].'",
												notify="'.$notify_value.'",
												birth_date="'.date("Y-m-d", strtotime($new_account['birth_date'])).'"
											WHERE
												username="'.$new_account['username'].'"
										';
									}
									$result = db_query($query);
									if(!$result) {
										echo '<script type="text/javascript">alert("Could not update account.")</script>';
										echo '<script type="text/javascript">window.history.back();</script>';
										goto end_if_106;
									}
									//Update account password
									if(!$edit_as_admin) {
										$password_change = addslashes($_POST['password']);
										if($new_account['password'] != "")
											$password_change = $new_account['password'];
										$pass_value = get_pass_value($new_account['username'], $password_change, false);
										$query = 'UPDATE '.$prefs['mysql_table_users'].'
											SET
												pass_value="'.$pass_value.'"
											WHERE
												username="'.$new_account['username'].'"
										';
										$result = db_query($query);
										if(!$result) {
											echo '<script type="text/javascript">alert("Could not update password.")</script>';
											echo '<script type="text/javascript">window.history.back();</script>';
											goto end_if_106;
										}
									}
									echo '<script type="text/javascript">window.location.assign(\'../settings.php\');</script>';
									end_if_106:
								} else if(isset($_POST['create_account_submit'])) {
									//Authenticate user
									if(addslashes($_POST['username']) == "" || addslashes($_POST['password']) == "") {
										echo "<script type='text/javascript'>alert('Please don\'t leave required fields black.')</script>";
										echo '<script type="text/javascript">window.history.back();</script>';
										goto end_if_107;
									}
									$auth_status = authenticateAdmin(addslashes($_POST['username']), addslashes($_POST['password']));
									if($auth_status != 0) {
										echo "<script type='text/javascript'>alert('The username and password combination is wrong')</script>";
										echo '<script type="text/javascript">window.history.back();</script>';
										goto end_if_107;
									}
									//Check if new user already exists
									$query = 'SELECT * FROM '.$prefs['mysql_table_users'].' WHERE username="'.addslashes($_POST['create_account_username']).'"';
									$result = db_query($query);
									if(!(!$result) && mysqli_num_rows($result) == 1) {
										echo "<script type='text/javascript'>alert('This username already exists.')</script>";
										echo '<script type="text/javascript">window.history.back();</script>';
										goto end_if_107;
									}
									$query = 'SELECT * FROM '.$prefs['mysql_table_users'].' WHERE email="'.addslashes($_POST['create_account_email']).'"';
									$result = db_query($query);
									if(!(!$result) && mysqli_num_rows($result) == 1) {
										echo "<script type='text/javascript'>alert('This email is already registered.')</script>";
										echo '<script type="text/javascript">window.history.back();</script>';
										goto end_if_107;
									}
									//check if password requested match
									if(addslashes($_POST['create_account_password']) != "" && addslashes($_POST['create_account_password']) != addslashes($_POST['create_account_password_retype'])) {
										echo "<script type='text/javascript'>alert('New password donsen\'t match the retype field.')</script>";
										echo '<script type="text/javascript">window.history.back();</script>';
										goto end_if_107;
									}
									//Create account
									$notify_value = 1;
									if(!isset($_POST['create_account_notify']))
										$notify_value = 0;
									$query = '
										INSERT INTO '. $prefs['mysql_table_users'] .'
											(email, username, permission, notify, first_name, middle_name, last_name, birth_date, creation_date, pass_value)
										VALUES
											(
											"'.addslashes($_POST['create_account_email']).'",
											"'.addslashes($_POST['create_account_username']).'",
											"'.addslashes($_POST['create_account_permission']).'",
											"'.$notify_value.'",
											"'.addslashes($_POST['create_account_first_name']).'",
											"'.addslashes($_POST['create_account_middle_name']).'",
											"'.addslashes($_POST['create_account_last_name']).'",
											"'.date("Y-m-d", strtotime($_POST['create_account_birth_date'])).'",
											"'.date("Y-m-d", strtotime("today")).'",
											""
											
											)
									';
									echo $query;
									$result = db_query($query);
									if(!$result) {
										echo "<script type='text/javascript'>alert('Could not create account.')</script>";
										echo '<script type="text/javascript">window.history.back();</script>';
										goto end_if_107;
									}
									//Update account password
									$password = addslashes($_POST['create_account_password']);
									$pass_value = get_pass_value(addslashes($_POST['create_account_username']), $password, false);
									$query = 'UPDATE '.$prefs['mysql_table_users'].'
										SET
											pass_value="'.$pass_value.'"
										WHERE
											username="'.addslashes($_POST['create_account_username']).'"
									';
									$result = db_query($query);
									if(!$result) {
										echo '<script type="text/javascript">alert("Account was not created properly. It exists but you won\'t be able to login")</script>';
										echo '<script type="text/javascript">window.history.back();</script>';
										goto end_if_107;
									}
									echo '<script type="text/javascript">window.location.assign(\'../settings.php\');</script>';
									end_if_107:
								} else {
									echo '
									<p> List all accounts <input type="submit" value="Go" name="list_all_accounts"></p>
									<p> Edit account: <input type="text" value="" name="edit_account_username"/><input type="submit" value="Go" name="edit_account"></p>
									<p> Create a new account: <input type="submit" value="Go" name="create_account"/></p>
									<p> Remove an account: <input type="text" value="" name="remove_account_username"/><input type="submit" value="Go" name="remove_account"/></p>
									';
								}
							?>
							</div>
						</div>
					</div>
				</div>
			</form>
		</div>
	</body>

</html>