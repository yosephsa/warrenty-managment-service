-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jul 14, 2016 at 01:33 PM
-- Server version: 10.1.13-MariaDB
-- PHP Version: 5.6.23

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `csc_it_wms`
--

-- --------------------------------------------------------

--
-- Table structure for table `users`
--
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `email` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `permission` varchar(20) NOT NULL DEFAULT 'user',
  `first_name` varchar(50) NOT NULL,
  `middle_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `birth_date` date NOT NULL,
  `creation_date` date NOT NULL,
  `pass_value` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`email`, `username`, `permission`, `first_name`, `middle_name`, `last_name`, `birth_date`, `creation_date`, `pass_value`) VALUES
('admin@localhost', 'admin', 'admin', 'Admin', '', '', '2016-07-14', '2016-07-14', '2ed2585f605f839497bbe20fc1b309d0e0ff7f04'),
('test@localhost', 'test', 'user', 'Test', 'T.', 'Altest', '2016-07-14', '2016-07-14', '');

-- --------------------------------------------------------

--
-- Table structure for table `warranties`
--
DROP TABLE IF EXISTS `warranties`;
CREATE TABLE `warranties` (
  `id` int(11) NOT NULL,
  `status` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'active',
  `product_name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `company_name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `price` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `notes` varchar(3000) COLLATE utf8_unicode_ci NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `created_by` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Unspecified',
  `creation_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `warranties`
--

INSERT INTO `warranties` (`id`, `status`, `product_name`, `company_name`, `price`, `notes`, `start_date`, `end_date`, `created_by`, `creation_date`) VALUES
(0, 'expired', 'Test Product 2 Warranty', 'Test Company', '$150', 'This is an expired test warranty.', '2016-05-12', '2016-06-30', 'Yoseph S. Alabdulwahab', '2016-05-12'),
(1, 'canceled', 'Test Product 3 Warranty', 'Test Company', '$389', 'This is an canceled test warranty.', '2016-07-12', '2016-07-30', 'Yoseph S. Alabdulwahab', '2016-07-12'),
(2, 'active', 'Test Product 1 Warranty ', 'Test Company', '$200', '<p>This is an active test warranty.</p>\r\n<p>I am using this as an example.</p>', '2016-07-13', '2016-07-30', 'Yoseph S. Alabdulwahab', '2016-07-12'),
(3, 'active', 'Test Product 4 Warranty', 'Test Company', '$3,000', 'This is an active test warranty that will not expire for a long time', '2014-07-12', '2017-07-12', 'Yoseph S. Alabdulwahab', '2014-07-13'),
(4, 'canceled', 'Test', 'Test', '$200', '<p>test</p>', '2016-07-13', '2016-07-14', 'Yoseph Alabdulwahab', '2016-07-13'),
(5, 'active', 'Testing date product', 'Date test product', '$200000', '<p>test</p>', '2016-07-14', '2016-07-20', 'Yoseph Alabdulwahab', '2016-07-14'),
(6, 'active', 'Test 20', 'Testers Inc', '$200', '<p>dfsfsdsdaf</p>', '2016-07-14', '2016-07-20', 'Yoseph Alabdulwahab', '2016-07-14'),
(7, 'active', 'Test 40', 'Testers Inc', '$200', '<p>dfsfsdsdaf</p>', '2016-07-14', '2016-07-21', 'Yoseph Alabdulwahab', '2016-07-14'),
(8, 'active', 'Test 80', 'Testers Inc', '$200', '<p>dfsfsdsdaf</p>', '2016-07-14', '2016-07-22', 'Yoseph Alabdulwahab', '2016-07-14');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`username`,`email`);

--
-- Indexes for table `warranties`
--
ALTER TABLE `warranties`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `warranties`
--
ALTER TABLE `warranties`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
