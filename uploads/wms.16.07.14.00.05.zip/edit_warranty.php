<!DOCTYPE html>
<html>
	<head>
		<?php
			include 'required_imports.php';
		?>
		<title>Warranty Managment System</title>
	</head>

	<body>
		<div class="wrapper">
			<?php
				include 'header.php';
			?>
			<form method="POST">
				<div class="control_menu">
					<div class="access_info">
							<text> Username: (*) </text>
							<input type="text" name="username"></input>
							<br/>
							<text> Password: (*) </text>
							<input type="password" name="password"></input>
					</div>
					<div class="actions">
						<input type="submit" value="Save" name="save"/>
						<input type="submit" value="Cancel Warranty" name="cancel"/>
					</div>
				</div>
				<div class="body_content">
					<?php
						if(isset($_GET['id']))
						{	
							if(!function_exists("connectReadDatabase")) {
								include 'mysql_connect.php';
							}
							if(!function_exists("search_warranties")) {
								include 'search_functions.php';
							}
							
							$status = "";
							
							$id = $_GET['id'];
							$product_name = "";
							$company_name = "";
							$notes = "";
							$date_range = "";
							$created_by = "";
							
							$result_set = search_warranties($id, $status, $product_name, $company_name, $notes, $date_range, $created_by);
							
							$result_set_array = array();
							while($row = mysqli_fetch_array($result_set)) {
								$result_set_array[] = $row;
							}
							
							$i = 0;
							while($i < sizeof($result_set_array)) {
								$id = $result_set_array[$i]['id'];
								$product_name = $result_set_array[$i]['product_name'];
								$company_name = $result_set_array[$i]['company_name'];
								$price = $result_set_array[$i]['price'];
								$notes = $result_set_array[$i]['notes'];
								$start_date = $result_set_array[$i]['start_date'];
								$end_date = $result_set_array[$i]['end_date'];
								$created_by = $result_set_array[$i]['created_by'];
								$creation_date = $result_set_array[$i]['creation_date'];
								$current_time = strtotime("today");
								$title_css = "";
								if(date_in_range($current_time, date("Y-m-d", strtotime("+60 day", $current_time)), $end_date)) {
									$title_css = "color: red;";
								}
								echo '
									<div class="entry">
										<div class="content">
											<div class="header">
												<div class="title"><p>Product Name: </p><input type="text" name="product_name" value="'.$product_name.'"></input></div>
												<div class="date"><p>Date (Y-M-D): </p><input type="text" name="end_date" value="'.$end_date.'"></input></div>
											</div>
											<hr/>
											<div class="details"><br/>
												<p>Company Name: </p><input type="text" name="company_name" value="'.$company_name.'"></input><br/>
												<p>Price: </p><input type="text" name="price" value="'.$price.'"></input><br/>
												<p>Notes: </p><div class"notes"><textarea name="notes" id="notes" class="notes"> '.$notes.' </textarea></div>
											</div>
										</div>
										<div class="actions" style="padding-top: 4em;">
											<br/><hr/><br/>
											<input type="submit" value="Save" name="save"/>
										</div>
									</div>
									<script>tinymce.init({ selector:\'textarea\' });</script>
								';
								
								$i = $i + 1;
							}
						}
						if((isset($_POST['cancel']) || isset($_POST['save'])) && isset($_POST['username'] ) && isset($_POST['password'])) {
							if(!function_exists("connectReadDatabase")) {
								include 'mysql_connect.php';
							}
							if(!function_exists("search_warranties")) {
								include 'search_functions.php';
							}
							if(!function_exists("authenticate"))
								include "user_auth.php";
							include 'constants.php';
							
							if($_POST['username'] == "" || $_POST['password'] == "") {
								echo "<script type='text/javascript'>alert('Please don\'t leave required fields black.')</script>";
								goto end_if_007;
							}
							$auth_status = authenticate($_POST['username'], $_POST['password']);
							$message = "";
							if($auth_status == 0) {
								if(isset($_POST['cancel'])) {
									$dbhandle = connectWriteDatabase();
									if($dbhandle->connect_error) {
										echo "<script type='text/javascript'>alert('Could not connect to database.')</script>";
										goto end_if_007;
									}
									$cancel_query = 'UPDATE '.$dbinfo['TABLE_WARRANTIES_NAME'].' SET status="canceled" WHERE id='.$_GET['id'].'';
									echo $cancel_query;
									$cancel_result = mysqli_query($dbhandle, $cancel_query);
									if(!$cancel_result) {
										echo "<script type='text/javascript'>alert('Could not cancel warranty')</script>";
									} else {
										echo "<script type='text/javascript'>alert('Warranty canceled Successfully')</script>";
									}
									mysqli_close($dbhandle);
								} else if(isset($_POST['save'])) {
									//Connect to database.
									$dbhandle = connectWriteDatabase();
									if($dbhandle->connect_error) {
										echo "<script type='text/javascript'>alert('Could not connect to database.')</script>";
										goto end_if_007;
									}
									
									//Creating query string
									$query = "UPDATE ". $dbinfo["TABLE_WARRANTIES_NAME"] ." 
										SET 
											product_name=\"".$_POST['product_name']."\", 
											company_name=\"".$_POST['company_name']."\",
											price=\"".$_POST['price']."\",
											notes=\"".$_POST['notes']."\",
											end_date=\"".$_POST['end_date']."\"
										WHERE
											id=".$_GET['id']."
											";
									//$query = "select * from warranties";
									echo htmlentities($query);
									//Sending query.
									$update_result = mysqli_query($dbhandle, $query);
									if(!$update_result)
										echo "<script type='text/javascript'>alert('Could not update warranty.')</script>";
									else {
										echo "<script type='text/javascript'>window.location.assign('/search.php/?id=".$_GET['id']."')</script>";
									}
									
									echo "<script type='text/javascript'>window.location.assign('/search.php/?id=".$_GET['id']."')</script>";
								}
							} else if($auth_status == 1) {
								echo "<script type='text/javascript'>alert('The username or password you entered is incorrect.')</script>";
							
							} else if($auth_status == 2) {
								echo "<script type='text/javascript'>alert('Could not connect to database.')</script>";
							} else{
								echo "<script type='text/javascript'>alert('Could not authenticate for an unknown reason.')</script>";
							}
							end_if_007:
						}
						
					?>
				
				</div>
			</form>
		</div>
	</body>

</html>