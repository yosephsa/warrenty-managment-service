<div class="menu">
	<img src="/imgs/logo.png"></img><br/>
	<ul>
		<li><a href="/">Home</a></li>
		<li><a href="/?status=active">Active</a></li>
		<li><a href="/?date_range=60">Near Expired</a></li>
		<li><a href="/?status=expired">Expired</a></li>
		<li><a href="/?status=canceled">Canceled</a></li>
		<li><a href="/add_warranty.php">Add</a></li>
	</ul>
</div>