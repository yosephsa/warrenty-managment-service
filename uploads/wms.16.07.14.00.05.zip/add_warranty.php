<!DOCTYPE html>
<html>
	<head>
		<?php
			include 'required_imports.php';
		?>
		<title>Warranty Managment System</title>
	</head>

	<body>
		<div class="wrapper">
			<?php
				include 'header.php';
			?>
			<form method="POST">
				<div class="control_menu">
					<div class="access_info">
							<text> Username (*): </text>
							<input type="text" name="username"></input>
							<br/>
							<br/>
							<text> Password (*):  </text>
							<input type="password" name="password"></input>
					</div>
					<div class="actions">
						<input type="submit" value="Create" name="create"/>
					</div>
				</div>
				<div class="body_content">
					<div class="entry">
						<div class="content">
							<div class="header">
								<div class="title"><p>Product Name: </p><input type="text" name="product_name" value=""></input></div>
								<?php
									echo '<div class="date"><p>Current Date (Y-M-D): </p><input type="text" name="end_date" value="'.date("Y-m-d", strtotime("today")).'" readonly></input></div>';
								?>
							</div>
							<hr/>
							<div class="details"><br/>
								<p>Company Name: </p><input type="text" name="company_name" value=""></input><br/>
								<p>Price: </p><input type="text" name="price" value=""></input><br/>
								<p>Start date: </p><input type="text" name="start_date" value=""></input><br/>
								<p>End date: </p><input type="text" name="end_date" value=""></input><br/>
								<p>Notes: </p><div class"notes"><textarea name="notes" id="notes" class="notes"></textarea></div>
							</div>
						</div>
						<div class="actions" style="padding-top: 4em;">
							<br/><hr/><br/>
							<input type="submit" value="Create" name="create"/>
						</div>
					</div>
					<script>tinymce.init({ selector:'textarea'});</script>
					<?php
						
						if(isset($_POST['create']) && isset($_POST['username'] ) && isset($_POST['password'])) {
							//Include necessaru files.
							if(!function_exists("connectReadDatabase")) {
								include 'mysql_connect.php';
							}
							if(!function_exists("search_warranties")) {
								include 'search_functions.php';
							}
							if(!function_exists("authenticate"))
								include "user_auth.php";
							include 'constants.php';
							
							//Check if required fields are blank.
							if($_POST['username'] == "" || $_POST['password'] == "") {
								echo "<script type='text/javascript'>alert('Please don\'t leave required fields black.')</script>";
								goto end_if_007;
							}
							
							//authenticate username and password.
							$auth_status = authenticate($_POST['username'], $_POST['password']);
							if($auth_status == 0) {
								if(isset($_POST['create'])) {
									//Connect to database.
									$dbhandle = connectWriteDatabase();
									if($dbhandle->connect_error) {
										echo "<script type='text/javascript'>alert('Could not connect to database.')</script>";
										goto end_if_006;
									}
									
									//Get name of user.
									$user_link = connectReadDatabase();
									$user_result = mysqli_query($user_link, "SELECT * FROM ".$dbinfo['TABLE_USERS_NAME']." WHERE username='".$_POST['username']."'");
									$user_result_arr = mysqli_fetch_array($user_result);
									$first_name = $user_result_arr['first_name'];
									$last_name = $user_result_arr['last_name'];
									mysqli_close($user_link);
									//Creating query string
									$query = 'INSERT INTO '. $dbinfo["TABLE_WARRANTIES_NAME"] .'
										(status, product_name, company_name, price, notes, start_date, end_date, created_by, creation_date)
										VALUES 
										  ( 
										    "active",
											"'.$_POST['product_name'].'", 
											"'.$_POST['company_name'].'",
											"'.$_POST['price'].'",
											"'.$_POST['notes'].'",
											"'.$_POST['start_date'].'",
											"'.$_POST['end_date'].'",
											"' . $first_name . " " . $last_name . '",
											"'.date("y-m-d", strtotime("today")).'" )
										';
									echo htmlentities($query);
									//Sending query.
									$update_result = mysqli_query($dbhandle, $query);
									if(!$update_result)
										echo "<script type='text/javascript'>alert('Could not update warranty.')</script>";
									else {
										echo "<script type='text/javascript'>window.location.assign('/search.php/?id=".$_GET['id']."')</script>";
									}
									mysqli_query($dbhandle, 'SELECT * FROM '.$dbinfo['TABLE_WARRANTIES_NAME'].' WHERE creation_date="'.date("y-m-d", strtotime("today")).'"');
									mysqli_close($dbhandle);
									//Redirect
									//echo "<script type='text/javascript'>window.location.assign('/search.php/?id=".$_GET['id']."')</script>";
									end_if_006:
								}
							} else if($auth_status == 1) {
								echo "<script type='text/javascript'>alert('The username or password you entered is incorrect.')</script>";
							
							} else if($auth_status == 2) {
								echo "<script type='text/javascript'>alert('Could not connect to database.')</script>";
							} else{
								echo "<script type='text/javascript'>alert('Could not authenticate for an unknown reason.')</script>";
							}
							end_if_007:
						}
						
					?>
				
				</div>
			</form>
		</div>
	</body>

</html>