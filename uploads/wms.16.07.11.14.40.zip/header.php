<div class="menu">
	<img src="/imgs/logo.png"></img><br/>
	<ul>
		<li><a href="/">Home</a></li>
		<li><a href="/index.php?active=1">Active</a></li>
		<li><a href="/index.php?active=0">Expired</a></li>
		<li><a href="/add_warranty.php">Add</a></li>
	</ul>
</div>