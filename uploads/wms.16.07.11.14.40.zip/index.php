<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>Warranty Managment System</title>
		<link rel="stylesheet" type="text/css" href="/style.css">
	</head>

	<body>
		<div class="wrapper">
			<?php
				include 'header.php';
			?>
			<div class="search">
				<div class="content">
					<div class="name">
						<text>Name: </text>
						<input type="text" name="name"/>
						<select>
							<option value="includes">Includes</option>
							<option value="starts">Starts With</option>
							<option value="ends">Ends With</option>
						</select>
					</div>
					<div class="owner">
						<text>Owner: </text>
						<input type="text" name="name"/>
						<select>
							<option value="includes">Includes</option>
							<option value="starts">Starts With</option>
							<option value="ends">Ends With</option>
						</select>
					</div>
					<div class="date_range">
						<text>Within: </text>
						<input type="text" name="name"/>
					</div>
				</div>
				<div class="submission">
					<div class="result_amount">
						<text>Show</text>
						<input type="text" name="result_amount" id="result_amount" value="20"/> 
					</div>
					<input type="submit" name="search" id="submit" value="Search"/>
				</div>
			</div>
			<div class="body_content">
			dksjfh<br/>
			dksjfh<br/>
			dksjfh<br/>
			dksjfh<br/>
			dksjfh<br/>
			dksjfh<br/>
			dksjfh<br/>
			dksjfh<br/>
			dksjfh<br/>
			dksjfh<br/>
			dksjfh<br/>
			dksjfh<br/>
			dksjfh<br/>
			dksjfh<br/>
			dksjfh<br/>
			dksjfh<br/>
			dksjfh<br/>
			dksjfh<br/>
			dksjfh<br/>
			dksjfh<br/>
			dksjfh<br/>
			dksjfh<br/>
			dksjfh<br/>
			dksjfh<br/>
			dksjfh<br/>
			dksjfh<br/>
			dksjfh<br/>
			dksjfh<br/>
			dksjfh<br/>
			
			</div>
		</div>
	</body>

</html>