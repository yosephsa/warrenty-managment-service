<?php
function get_preferences() {
	return parse_ini_file("/preferences.ini");
}

?>