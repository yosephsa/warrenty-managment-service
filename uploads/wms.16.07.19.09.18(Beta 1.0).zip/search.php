<?php
        $num = $_GET["id"];
        if(!is_numeric($num) || $num < 0) {
            header('Location: /');
            exit();
        }
?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>Warranty Managment System</title>
		<link rel="stylesheet" type="text/css" href="/style.css">
	</head>

	<body>
		<div class="wrapper">
			<?php
				include_once 'header.php';
			?>
			
			<form class="control_menu" method="POST">
				<?php
					include_once '/login.php';
				?>
				<div class="actions">
					<input type="submit" value="Edit" name="edit" />
				</div>
			</form>
			
			<div class="body_content">
				<?php
					if(isset($_GET['id']))
					{
						include_once 'mysql_connect.php';
						include_once 'search_functions.php';
						
						$status = "";
						
						$id = addslashes($_GET['id']);
						$product_name = "";
						$company_name = "";
						$contact_info = "";
						$notes = "";
						$date_range = "";
						$created_by = "";
						
						$result_set = search_warranties($id, $status, $product_name, $company_name, $contact_info, $notes, $date_range, $created_by);
						
						$result_set_array = array();
						while($row = mysqli_fetch_array($result_set)) {
							$result_set_array[] = $row;
						}
						
						$i = 0;
						while($i < sizeof($result_set_array)) {
							$id = $result_set_array[$i]['id'];
							$product_name = $result_set_array[$i]['product_name'];
							$company_name = $result_set_array[$i]['company_name'];
							$price = $result_set_array[$i]['price'];
							$contact_info = $result_set_array[$i]['contact_info'];
							$notes = $result_set_array[$i]['notes'];
							$start_date = $result_set_array[$i]['start_date'];
							$end_date = $result_set_array[$i]['end_date'];
							$created_by = $result_set_array[$i]['created_by'];
							$creation_date = $result_set_array[$i]['creation_date'];
							$current_time = strtotime("today");
							$title_css = "";
							if(date_in_range($current_time, date("Y-m-d", strtotime("+60 day", $current_time)), $end_date)) {
								$title_css = "color: red;";
							}
							echo '
							<div class="entry">
								<div class="content">
									<div class="header">
										<text class="title"> <a href="/search.php?id='.$id.'" style="'.$title_css.'">'.$product_name.'</a></text>
										<text class="date">'.$company_name.'</text>
									</div>
									<hr/>
									<div class="details"><br/>
										<p> Warranty Period: <text style="color: #000066;">'.date('j F Y', strtotime($start_date)). '</text> to <text style="color: #000066;">' .date('j F Y', strtotime($end_date)).'</text></p><br/>
										<p> Price: '.$price.' </p><br/>
										<p> Contact Info: '.$contact_info.' </p><br/>
										<p> Notes: '.$notes.' </p><br/>
										<p> Created by: '.$created_by.' </p><br/>
									</div>
								</div>
							</div>
							';
							
							$i = $i + 1;
						}
					}
					if(isset($_POST['edit']) && isset($_POST['username'] ) && isset($_POST['password'])) {
						if(addslashes($_POST['username']) == "" && addslashes($_POST['password']) == "") {
							echo "<script type='text/javascript'>alert('Please don\'t leave required fields black.')</script>";
							goto end_if_3031;
						}
						include_once 'user_auth.php';
						$auth_status = authenticate(addslashes($_POST['username']), addslashes($_POST['password']));
						$message = "";
						if($auth_status == 0) {
							if(isset($_POST['edit'])) {
								echo "<script type='text/javascript'>window.location.assign('/edit_warranty.php/?id=".$_GET['id']."')</script>";
							}
						} else if($auth_status == 1) {
							echo "<script type='text/javascript'>alert('The username or password you entered is incorrect.')</script>";
						
						} else if($auth_status == 2) {
							echo "<script type='text/javascript'>alert('Could not connect to database.')</script>";
						} else{
							echo "<script type='text/javascript'>alert('Could not authenticate for an unknown reason.')</script>";
						}
						end_if_3031:
					}
					
				?>
			</div>
		</div>
	</body>

</html>