<?php
	function connectDatabase() {
		include_once "/constants.php";
		$prefs = get_preferences();
		return mysqli_connect($prefs['mysql_host'], $prefs['mysql_user_write'], $prefs['mysql_pass_write'], $prefs['mysql_database']);
	}
	function db_query($query) {
		$link = connectDatabase();
		return mysqli_query($link, $query);
	}
?>