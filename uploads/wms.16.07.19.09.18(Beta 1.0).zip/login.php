<?php echo '
	<div class="access_info">
		<table>
			<tr>
				<th><label> Username (*): </label></th>
				<th><input type="text" name="username" style="margin-bottom: 0.5em;"></input></th>
			</tr>
			
			<tr>
				<th><label> Password (*):  </label></th>
				<th><input type="password" name="password"></input></th>
			</tr>
		</table>
	</div>
';?>