<meta charset="UTF-8">
<link rel="stylesheet" type="text/css" href="/style.css">
<script src="//cdn.tinymce.com/4/tinymce.min.js"></script>