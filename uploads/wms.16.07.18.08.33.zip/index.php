<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>Warranty Managment System</title>
		<link rel="stylesheet" type="text/css" href="/style.css">
	</head>

	<body>
		<div class="wrapper">
			<?php
				include 'header.php';
			?>
			<form class="search" method="POST">
				<div class="content">
					<text>Product Name: </text>
					<input type="text" name="product_name" style="margin-bottom: 0.5em;"/><br/>
					<text>Company Name: </text>
					<input type="text" name="company_name" style="margin-bottom: 0.5em;"/><br/>
					<text>Within ( Days ): </text>
					<input type="text" name="date_range"/>
				</div>
				<div class="content">
					<text>Created By: </text>
					<input type="text" name="created_by" style="margin-bottom: 0.5em;"/><br/>
					<text>Notes (Contain): </text>
					<input type="text" name="notes"/>
				</div>
				<div class="submission">
					<text>Show</text>
					<input type="text" name="result_amount" id="result_amount" value="20" style="width: 2em;"/> 
					<input type="submit" name="submit" value="submit" onClick="location.reload(false);" id="submit" />
				</div>
			</form>
			<div class="body_content">
				<?php
					//For some reason I still can't find submit from post for some reason.
					if(isset($_POST['submit']))
					{
						if(!function_exists("connectDatabase")) {
							include 'mysql_connect.php';
						}
						if(!function_exists("search_warranties")) {
							include 'search_functions.php';
						}
						
						$result_amount = $_POST['result_amount'];
						
						$status = "";
						if(isset($_GET['status'])) {
							$status = $_GET['status'];
						}
						
						$id = "";
						$product_name = $_POST['product_name'];
						$company_name = $_POST['company_name'];
						$contact_info = $_POST['contact_info'];
						$notes = $_POST['notes'];
						$date_range = $_POST['date_range'];
						if(isset($_GET['date_range'])) {
							$date_range = $_GET['date_range'];
						}
						$created_by = $_POST['created_by'];
						search($id, $status, $product_name, $company_name, $contact_info, $notes, $date_range, $created_by, $result_amount);
						
					} else {
						$result_amount = 10;
						
						$status = "active";
						if(isset($_GET['status'])) {
							$status = $_GET['status'];
						}
						
						$id = "";
						$product_name = "";
						$company_name = "";
						$contact_info = "";
						$notes = "";
						$date_range = "";
						if(isset($_GET['date_range'])) {
							$date_range = $_GET['date_range'];
						}
						$created_by = "";
						search($id, $status, $product_name, $company_name, $contact_info, $notes, $date_range, $created_by, $result_amount);
					}
					
					function search($id, $status, $product_name, $company_name, $contact_info, $notes, $date_range, $created_by, $result_amount) {
						
						if(!function_exists("connectReadDatabase")) {
							include 'mysql_connect.php';
						}
						if(!function_exists("search_warranties")) {
							include 'search_functions.php';
						}
						
						$result_set = search_warranties($id, $status, $product_name, $company_name, $contact_info, $notes, $date_range, $created_by);
						
						$result_set_array = array();
						while($row = mysqli_fetch_array($result_set)) {
							$result_set_array[] = $row;
						}
						
						$i = 0;
						while($i < sizeof($result_set_array) && $i < $result_amount) {
							$id = $result_set_array[$i]['id'];
							$product_name = $result_set_array[$i]['product_name'];
							$company_name = $result_set_array[$i]['company_name'];
							$price = $result_set_array[$i]['price'];
							$notes = $result_set_array[$i]['notes'];
							$start_date = $result_set_array[$i]['start_date'];
							$end_date = $result_set_array[$i]['end_date'];
							$created_by = $result_set_array[$i]['created_by'];
							$creation_date = $result_set_array[$i]['creation_date'];
							$current_time = strtotime("today");
							$title_css = "";
							if(date_in_range($current_time, date("y-m-d", strtotime("+20 day", $current_time)), $end_date)) {
								$title_css = "color: red;";
							}
							echo "<div class=\"entry_brief\">
								<div class=\"content\">
									<div class=\"title\">
										<text> <a href=\"/search.php?id=".$id."\" style=\"".$title_css."\">".$product_name."</a> </text>
									</div>
									<div class=\"details\">
										<text> ".$company_name." </text>
									</div>
								</div>
								<div class=\"date\">
									<text>".date("j F Y", strtotime($end_date))."</text>
								</div>
							</div>";
							$i = $i + 1;
						}
					}
				?>
			</div>
		</div>
	</body>

</html>