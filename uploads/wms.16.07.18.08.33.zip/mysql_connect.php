<?php
	function connectReadDatabase() {
		include "constants.php";
		return mysqli_connect($dbinfo['HOST_NAME'], $dbinfo['READ_USER'], $dbinfo['READ_PASS'], $dbinfo['DB_NAME']);
	}
	function connectWriteDatabase() {
		include "constants.php";
		return mysqli_connect($dbinfo['HOST_NAME'], $dbinfo['WRITE_USER'], $dbinfo['WRITE_PASS'], $dbinfo['DB_NAME']);
	}
?>