<?php

$dbinfo = array("HOST_NAME"=>"localhost",
					"DB_NAME"=>"csc_it_wms",
					"TABLE_WARRANTIES_NAME"=>"warranties",
					"TABLE_USERS_NAME"=>"users",
					"READ_USER"=>"csc_it_wms_read",
					"READ_PASS"=>"Read@123",
					"WRITE_USER"=>"csc_it_wms_write",
					"WRITE_PASS"=>"@S2e0c1u6re");
					
?>