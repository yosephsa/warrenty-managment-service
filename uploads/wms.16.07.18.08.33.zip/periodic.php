<?php
	updateWarrantyStatus();
	notifyOfExperation();
	function updateWarrantyStatus() {
		if(!function_exists('connectReadDatabase')) {
			include 'mysql_connect.php';
		}
		include 'constants.php';
		$dbhandle = connectReadDatabase();
		$query = 'SELECT * FROM '.$dbinfo['TABLE_WARRANTIES_NAME'].' WHERE status="active" AND end_date < CURRENT_DATE()';
		$result = mysqli_query($dbhandle, $query);
		$query = 'UPDATE '.$dbinfo["TABLE_WARRANTIES_NAME"].' SET status="expired" WHERE ';
		$i=0;
		while($row = mysqli_fetch_array($result)) {
			if($i!=0)
				$query.=' AND ';
			$query .= 'id='.$row["id"];
		}
		echo 'Update status query: '.$query.'<br/>';
		mysqli_close($dbhandle);
		$dbhandle = connectWriteDatabase();
		$result = mysqli_query($dbhandle, $query);
		mysqli_close($dbhandle);
	}
	function notifyOfExperation() {
		//Include necessary files.
		if(!function_exists('connectReadDatabase')) {
			include 'mysql_connect.php';
		}
		include 'constants.php';
		
		//Connect to database.
		$dbhandle = connectReadDatabase();
		$nd_start = date("Y-m-d", strtotime("today"));
		$nd_end = date("Y-m-d", strtotime("+60 days"));
		
		
		//Retrives warranties and emailers list.
		$query_warranties = 'SELECT * FROM '.$dbinfo['TABLE_WARRANTIES_NAME'].' WHERE status="active" AND notification_count < 4 AND end_date between "'.$nd_start.'" AND "'.$nd_end.'"';
		echo 'Warranties Query = ' . $query_warranties . '<br/>';
		$query_notify = 'SELECT * FROM '.$dbinfo['TABLE_USERS_NAME'].' WHERE notify=1';
		echo 'Notify Query = ' . $query_notify . '<br/>';
		$result_warranties = mysqli_query($dbhandle, $query_warranties);
		$result_notify = mysqli_query($dbhandle, $query_notify);
		if(!$result_notify) {
			echo 'No emailers to send to.';
			return;
		}
		if(!$result_warranties) {
			echo 'No warranties to notify about.';
			return;
		}
		//Creating necessary emailing fields.
		$to = '';
		$subject = 'Some Warranties Will Expire Soon.';
		$message = '';
		$headers = "MIME-Version: 1.0" . "\r\n";
		$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
		$headers .= 'From: <webmaster@example.com>' . "\r\n";
		
		//Add emailers to send list.
		$i = 0;
		while($row = mysqli_fetch_array($result_notify)) {
			if($i == 0)
				$to .= $row['email'];
			else
				$to .= ', ' . $row['email'];
			$i += 1;
		}
		
		//Composing email body.
		$message .= '
			<p>Dear Admin,</p>
			<p>The following warranties are ending soon.</p>
			<ul>
			';
		$i = 0;
		while($row = mysqli_fetch_array($result_warranties)) {
			$num_days_remaining;
			$letter_s = "s";
			switch($row['notification_count']) {
				case 0: $num_days_remaining=60; break;
				case 1: $num_days_remaining=30; break;
				case 2: $num_days_remaining=10; break;
				case 3: 
					$num_days_remaining=1; 
					$letter_s=''; 
					break;
			}
			$message .= '<li style="padding-left: 30px;">In '.$num_days_remaining.' day'.$letter_s.', <a href="/search.php/?id='.$row['id'].'">'.$row['product_name'].'</a> will expire.</li>';
		}
		$message .= '
			</ul>
			<p>To view a specific warranty you may click the warranty name, or go to the near expiring page.</p>
			<p>Thank you.</p>
			<p>&nbsp;</p>';
		echo '<br/><br/> Email: <br/>
		<p style="padding-left: 30px;">
			Subject: '.$subject.'<br/>
			To: '.$to.'<br/>
			Header: '.$headers.'<br/>
			Message: <br/>'.$message.'<br/>
			
		</p>';
		mail($to,$subject,$message,$headers);
	}
?>