-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jul 18, 2016 at 07:31 AM
-- Server version: 10.1.10-MariaDB
-- PHP Version: 5.5.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `csc_it_wms`
--

-- --------------------------------------------------------

--
-- Table structure for table `log`
--

DROP TABLE IF EXISTS `log`;
CREATE TABLE `log` (
  `id` int(11) NOT NULL,
  `type` varchar(20) NOT NULL DEFAULT 'warranties',
  `changed_id` varchar(50) NOT NULL,
  `log` text NOT NULL,
  `changed_by` varchar(50) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `email` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `permission` varchar(20) NOT NULL DEFAULT 'user',
  `first_name` varchar(50) NOT NULL,
  `middle_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `notify` tinyint(1) NOT NULL DEFAULT '1',
  `birth_date` date NOT NULL,
  `creation_date` date NOT NULL,
  `pass_value` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`email`, `username`, `permission`, `first_name`, `middle_name`, `last_name`, `notify`, `birth_date`, `creation_date`, `pass_value`) VALUES
('admin@localhost', 'admin', 'admin', 'Admin', '', '', 0, '2016-07-14', '2016-07-14', '2ed2585f605f839497bbe20fc1b309d0e0ff7f04'),
('ralfrayan@csc.org.sa', 'ralfrayan', 'user', 'Reem', 'A.', 'Alfrayan', 1, '1975-04-30', '2016-07-17', 'a36f8beb17f42260686427574d4f688f7bc8bf72'),
('yosephsa0@gmail.com', 'yoseph1998', 'admin', 'Yoseph', 'S.', 'Alabdulwahab', 1, '1998-12-30', '2016-07-15', '516c87dfa8ef4ef4f165ff7d27dcb60c495fdb26');

-- --------------------------------------------------------

--
-- Table structure for table `warranties`
--

DROP TABLE IF EXISTS `warranties`;
CREATE TABLE `warranties` (
  `id` int(11) NOT NULL,
  `status` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'active',
  `product_name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `company_name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `price` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `contact_info` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `notes` varchar(3000) COLLATE utf8_unicode_ci NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `created_by` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Unspecified',
  `creation_date` date NOT NULL,
  `notification_count` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `warranties`
--

INSERT INTO `warranties` (`id`, `status`, `product_name`, `company_name`, `price`, `contact_info`, `notes`, `start_date`, `end_date`, `created_by`, `creation_date`, `notification_count`) VALUES
(0, 'expired', 'Refrigerator Quality Help Desk', 'Refrigerators Inc.', '$10', '', '<p>If anything about your fridge is unsatisfying get your full money back.</p>', '2016-07-01', '2016-07-12', 'Yoseph S. Alabdulwahab', '2016-07-17', 0),
(1, 'active', 'Mojo', 'Mojo Jojo Inc.', '$100', '', '<p>They will upgrade if we buy a whole year.</p>', '2016-07-19', '2017-12-20', 'Yoseph S. Alabdulwahab', '2016-07-17', 0),
(2, 'active', 'Daddy Daycare Company Service', 'Daddy Daycare.', '$25', '<p>Main sales person: sales@example.com</p>', '<p>Will provide daycare services to any employee who needs.</p>', '2016-07-17', '2016-07-29', 'Reem A. Alfrayan', '2016-07-17', 0),
(3, 'canceled', 'Certified Typer''s Efficiency', 'Type Trainers Inc.', '$3,500', '', '<p>&nbsp;If a trained typer is asked to take a certified typers test and fails he/she is eligible to take more training courses till the typer passes.</p>', '2014-01-17', '2016-07-02', 'Yoseph S. Alabdulwahab', '2016-07-17', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `log`
--
ALTER TABLE `log`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`username`,`email`);

--
-- Indexes for table `warranties`
--
ALTER TABLE `warranties`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `warranties`
--
ALTER TABLE `warranties`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
